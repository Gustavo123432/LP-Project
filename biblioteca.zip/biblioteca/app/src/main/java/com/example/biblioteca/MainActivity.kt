package com.example.biblioteca

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.ProgressBar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var progressBar : ProgressBar
    private val tempoTotal = 1500
    private val intervaloTempo = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        progressBar = findViewById(R.id.progressBar)

        val countDownTimer = object : CountDownTimer(tempoTotal.toLong(), intervaloTempo.toLong()) {
            override fun onTick(millisUntilFinished: Long) {
                progressBar.visibility = View.VISIBLE
                val progress = ((tempoTotal.toLong() - millisUntilFinished).toFloat() / tempoTotal.toLong() * 100).toInt()
                progressBar.progress = progress
            }

            override fun onFinish() {
                val intent = Intent(this@MainActivity, InicialLivroPageActivity::class.java);
                startActivity(intent)
                progressBar.progress = 100
            }
        }
        countDownTimer.start()

    }

}