package com.example.myapplication.models

data class UvInformation(
    val globalIdLocal: String,
    val iUv: String,
    val data: String
)
