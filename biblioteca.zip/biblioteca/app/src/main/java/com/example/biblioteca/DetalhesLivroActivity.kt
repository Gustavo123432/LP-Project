package com.example.biblioteca

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide

class DetalhesLivroActivity : AppCompatActivity() {

    private lateinit var tituloTextView: TextView
    private lateinit var autorTextView: TextView
    private lateinit var editoraTextView: TextView
    private lateinit var anoTextView: TextView
    private lateinit var imageView: ImageView
    private lateinit var button : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detalhes_livro)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        tituloTextView = findViewById(R.id.tituloEditText)
        autorTextView = findViewById(R.id.autortextView)
        editoraTextView = findViewById(R.id.editoraEditText)
        anoTextView = findViewById(R.id.anoTextView)
        imageView = findViewById(R.id.livroImagemView)

        button = findViewById(R.id.button2)



        val intent = intent

        val titulo = intent.getStringExtra("titulo")
        val autor = intent.getStringExtra("autor")
        val editora =  intent.getStringExtra("editora")
        val ano = intent.getStringExtra("ano")
        val imagem = intent.getStringExtra("imagem")


        tituloTextView.setText(titulo)
        autorTextView.setText(autor)
        editoraTextView.setText(editora)
        anoTextView.setText(ano)
        Glide.with(this)
            .load(imagem)
            .into(imageView)

        button.setOnClickListener {
            val intent = Intent(this, EditarLivroActivity::class.java)
            intent.putExtra("titulo", titulo)
            intent.putExtra("autor", autor)
            intent.putExtra("editora", editora)
            intent.putExtra("ano", ano)
            intent.putExtra("imagem", imagem)
            startActivity(intent)
        }


    }
}