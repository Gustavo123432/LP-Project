package com.example.myapplication.models

data class TempoInformation(
    val dia: String,
    val tempoImage: String,
    val minTemperatura : String,
    val maxTemperatura : String,
    val ventoDirection : String,
    val precipition : String
)
