package com.example.biblioteca.api

import com.example.biblioteca.models.LivroInformation
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.GET
import retrofit2.http.POST

interface Endpoint {
    @GET("/app/books")
    fun getLivros() : Call<JsonArray>

    @POST("/app/books")
    fun createPost(
        @Field("uuid") uuid: String,
        @Field("editor") editor: String,
        @Field("author") author: String,
        @Field("imageUrl") imageUrl: String,
        @Field("title") title: String,
        @Field("year") year: Int
    ): Call<LivroInformation>
}