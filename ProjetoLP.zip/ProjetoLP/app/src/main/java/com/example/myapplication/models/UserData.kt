package com.example.myapplication.models

data class UserData (
    val Locais: List<String?> = listOf(null, ""),
    val nomeUtilizador: String = ""
)