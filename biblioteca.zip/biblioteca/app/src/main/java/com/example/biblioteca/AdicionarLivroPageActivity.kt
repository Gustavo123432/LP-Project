package com.example.biblioteca

import android.app.Activity
import android.content.ContentValues.TAG
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.marginTop
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.biblioteca.adapters.LivrosCustomAdapter
import com.example.biblioteca.api.Endpoint
import com.example.biblioteca.models.LivroInformation
import com.example.biblioteca.util.NetworkUtils
import com.google.gson.JsonArray
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Response
import java.util.UUID
import kotlin.time.TestTimeSource

class AdicionarLivroPageActivity : AppCompatActivity() {
    private lateinit var tituloEditText : EditText
    private lateinit var autorEditText: EditText
    private lateinit var editoraEditText: EditText
    private lateinit var anoEditText: EditText
    private lateinit var addImagemTextView: TextView
    private lateinit var addLivroButton: Button
    private lateinit var livroAddImageView : ImageView
    private lateinit var toolbar: Toolbar
    private lateinit var tituloOb: TextView
    private lateinit var autorOb: TextView
    private lateinit var anoOb: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_adicionar_livro_page)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        tituloEditText = findViewById(R.id.tituloEditText)
        autorEditText = findViewById(R.id.autorEditText)
        editoraEditText = findViewById(R.id.editoraEditText)
        anoEditText = findViewById(R.id.anoEditText)
        addLivroButton = findViewById(R.id.adicionarLivroButton)
        addImagemTextView = findViewById(R.id.addImageTextView)
        livroAddImageView = findViewById(R.id.livroAddImageView)
        tituloOb = findViewById(R.id.tituloObrigatorioTextView)
        autorOb = findViewById(R.id.autorObTextView)
        anoOb = findViewById(R.id.anoObTextView)

        addImagemTextView.setOnClickListener {
            escolha()
        }

        addLivroButton.setOnClickListener {
           if(tituloEditText.equals("") || autorEditText.equals("") || anoEditText.equals("")){
               validing()
           }
            /*else{
               sendAPI(tituloEditText.text.toString(), editoraEditText.text.toString(), autorEditText.text.toString(), Integer.parseInt(anoEditText.text.toString()),"")
           }*/
        }

    }

    fun sendAPI(titulo : String, editor: String, autor: String, ano:Int, imageUrl: String){
        val retrofitClient =
            NetworkUtils.getRetrofitInstance("https://us-central1-word-skills-dfe98.cloudfunctions.net/")
        val endpoint = retrofitClient.create(Endpoint::class.java)
        val myUuid = UUID.randomUUID()
        val myUuidAsString = myUuid.toString()


        endpoint.createPost(myUuidAsString, editor, autor, imageUrl, titulo, ano).enqueue(object : retrofit2.Callback<LivroInformation> {
            override fun onResponse(call: Call<LivroInformation>, response: Response<LivroInformation>) {
                if(response.isSuccessful()) {
                    Log.e("testssssss",response.body().toString() )
                    Log.i(TAG, "post submitted to API." + response.body().toString())
                }
            }

            override fun onFailure(call: Call<LivroInformation>, t: Throwable) {
                TODO("Not yet implemented")
            }
        })
        }

    fun validing(){
        if(tituloEditText.equals("")){
            tituloOb.visibility = View.VISIBLE
        }
        else{
            tituloOb.visibility = View.INVISIBLE
        }
        if(autorEditText.equals("")){
            autorOb.visibility = View.VISIBLE
        }else{
            autorOb.visibility = View.INVISIBLE
        }
        if(anoEditText.equals("")) {
            anoOb.visibility = View.VISIBLE
        }else{
            anoOb.visibility = View.INVISIBLE
        }
    }

    fun initToolbar(){

        val toolbar = findViewById<Toolbar>(R.id.toolbar);


    }

    //add Image and Capture Options
    private fun escolha() {
        val pictureDialog = AlertDialog.Builder(this)
        pictureDialog.setTitle("Selecione a Ação")
        val pictureDialogItems = arrayOf("Selecionar da Galeria", "Abrir Câmera")
        pictureDialog.setItems(pictureDialogItems) { _, which ->
            when (which) {
                0 -> selecionarFotoGaleria()
                1 -> abrirCamera()
            }
        }
        pictureDialog.show()
    }

    private fun selecionarFotoGaleria() {
        val galeriaGo = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        resultadoDaGaleriaLaunch.launch(galeriaGo)
    }

    private val resultadoDaGaleriaLaunch = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            val contentURI: Uri? = data?.data
            contentURI?.let {
                livroAddImageView.setImageURI(it)
                livroAddImageView.visibility = View.VISIBLE

            }
        }
    }

    // Declaração da variável para armazenar o código da imagem capturada
    private val REQUEST_IMAGE_CAPTURE = 1

    // Função para tirar a foto usando a câmera
    private fun abrirCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, REQUEST_IMAGE_CAPTURE)
    }

    // Método para lidar com o resultado da captura da imagem
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            livroAddImageView.setImageBitmap(imageBitmap)
            livroAddImageView.visibility = View.VISIBLE
        }
    }



}