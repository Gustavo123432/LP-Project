package com.example.biblioteca.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.biblioteca.R
import com.example.biblioteca.models.LivroInformation

class LivrosCustomAdapter (
    private val dataSet: ArrayList<LivroInformation>,
    private val context: Context,
    private val listener: RecyclerViewEvent
    ) : RecyclerView.Adapter<LivrosCustomAdapter.ViewHolder>() {

        class ViewHolder(view: View, private val listener: RecyclerViewEvent) : RecyclerView.ViewHolder(view), View.OnClickListener {
            val nomeLivroTextView: TextView = view.findViewById(R.id.nomeLivroTextView)
            val nomeAutorTextView: TextView = view.findViewById(R.id.nomeAutorTextView)
            val livroImageView: ImageView = view.findViewById(R.id.livroImageView)

            init {
                view.setOnClickListener(this)
            }

            override fun onClick(view: View?) {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(position)
                }
            }
        }

        override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.livros, viewGroup, false)
            return ViewHolder(view, listener)
        }

        override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
            val data = dataSet[position]

            viewHolder.nomeLivroTextView.text = data.title
            viewHolder.nomeAutorTextView.text = data.author
            Glide.with(context)
                .load(data.imageUrl)
                .into(viewHolder.livroImageView)

        }

        override fun getItemCount(): Int = dataSet.size
        interface RecyclerViewEvent {
            fun onItemClick(position: Int)
        }
}