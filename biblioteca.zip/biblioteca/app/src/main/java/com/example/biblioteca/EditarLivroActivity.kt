package com.example.biblioteca

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide

class EditarLivroActivity : AppCompatActivity() {

    private lateinit var tituloEditText: EditText
    private lateinit var autorEditText: EditText
    private lateinit var editoraEditText: EditText
    private lateinit var anoEditText: EditText
    private lateinit var imageView: ImageView
    private lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_editar_livro)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        tituloEditText = findViewById(R.id.tituloEditText)
        autorEditText = findViewById(R.id.autorEditText)
        editoraEditText = findViewById(R.id.editoraEditText)
        anoEditText = findViewById(R.id.anoEditText)
        imageView = findViewById(R.id.livroImageView)
        button = findViewById(R.id.button)

        val intent = intent

        val titulo = intent.getStringExtra("titulo")
        val autor = intent.getStringExtra("autor")
        val editora =  intent.getStringExtra("editora")
        val ano = intent.getStringExtra("ano")
        val imagem = intent.getStringExtra("imagem")


        tituloEditText.setText(titulo)
        autorEditText.setText(autor)
        editoraEditText.setText(editora)
        anoEditText.setText(ano)
        Glide.with(this)
            .load(imagem)
            .into(imageView)

        button.setOnClickListener {
            val intent = Intent(this, DetalhesLivroActivity::class.java)
            intent.putExtra("titulo", titulo)
            intent.putExtra("autor", autor)
            intent.putExtra("editora", editora)
            intent.putExtra("ano", ano)
            intent.putExtra("imagem", imagem)
            startActivity(intent)
        }
    }
}