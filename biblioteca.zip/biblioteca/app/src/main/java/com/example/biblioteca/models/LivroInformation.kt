package com.example.biblioteca.models

data class LivroInformation (
    val uuid: String,
    val editor: String,
    val author : String,
    val imageUrl : String,
    val title : String,
    val year : Int
)