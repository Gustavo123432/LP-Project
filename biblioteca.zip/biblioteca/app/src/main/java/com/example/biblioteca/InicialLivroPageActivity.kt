package com.example.biblioteca

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.biblioteca.adapters.LivrosCustomAdapter
import com.example.biblioteca.api.Endpoint
import com.example.biblioteca.models.LivroInformation
import com.google.gson.JsonObject
import com.example.biblioteca.util.NetworkUtils
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.gson.JsonArray
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class InicialLivroPageActivity : AppCompatActivity(), LivrosCustomAdapter.RecyclerViewEvent {

    private lateinit var recyclerView: RecyclerView
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var floatingActionButton: FloatingActionButton

    var livroInformation = ArrayList<LivroInformation>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_inicial_livro_page)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        recyclerView = findViewById(R.id.recyclerView)
        floatingActionButton = findViewById(R.id.floatingActionButton)
        getLivros()
        floatingActionButton.setOnClickListener {
            val intent = Intent(this, AdicionarLivroPageActivity::class.java)
            startActivity(intent)
        }
    }

    fun getLivros() {
        val retrofitClient =
            NetworkUtils.getRetrofitInstance("https://us-central1-word-skills-dfe98.cloudfunctions.net/")
        val endpoint = retrofitClient.create(Endpoint::class.java)

        endpoint.getLivros().enqueue(object : retrofit2.Callback<JsonArray> {
            override fun onResponse(call: Call<JsonArray>, response: Response<JsonArray>) {
                val body = response.body()


                // criar model to get the data
                if (body != null) {
                    val jsonArray = body.getAsJsonArray()

                    jsonArray?.forEach { element ->
                        val jsonObject = element.asJsonObject
                        val uuid = jsonObject.get("uuid").asString
                        val editor = jsonObject.get("editor").asString
                        val author = jsonObject.get("author").asString
                        val imageUrl = jsonObject.get("imageUrl").asString
                        val title = jsonObject.get("title").asString
                        val year = jsonObject.get("year").asInt

                        val information =
                            LivroInformation(uuid, editor, author, imageUrl, title, year)
                        // Preencha o mapa com os nomes dos distritos e seus IDs globais
                        livroInformation.add(information)
                    }
                    val livroCustomAdapter = LivrosCustomAdapter(livroInformation, this@InicialLivroPageActivity, this@InicialLivroPageActivity)
                    recyclerView.layoutManager = LinearLayoutManager(this@InicialLivroPageActivity, LinearLayoutManager.VERTICAL, false)
                    recyclerView.adapter = livroCustomAdapter
                }
            }


            override fun onFailure(call: Call<JsonArray>, t: Throwable) {
                print("Não dá")

            }


        })
    }
    override fun onItemClick(position: Int) {
        /*editor.putString("lala", tempoInfomationn[position].dia)
        editor.apply()
        Log.e("Your Tag for identy", tempoInfomationn[position].dia);*/
       val intent = Intent(this, DetalhesLivroActivity::class.java)
        intent.putExtra("titulo", livroInformation[position].title)
        intent.putExtra("autor", livroInformation[position].author)
        intent.putExtra("editora", livroInformation[position].editor)
        intent.putExtra("ano", livroInformation[position].year.toString())
        intent.putExtra("imagem", livroInformation[position].imageUrl)
        startActivity(intent)


    }
}